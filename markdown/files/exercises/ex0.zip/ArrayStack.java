public class ArrayStack<T> implements MyStack<T> {
    
}

public class ArrayQueue<T> implements MyQueue<T>{
    
}
